
Three.js TrackballControls
------

Official file https://github.com/mrdoob/three.js/blob/master/examples/js/controls/TrackballControls.js

### Usage

```
bower install --save threejs-trackball-controls
```

### License

MIT
